/* ==================================================================
 * ТОЧКА СБРОСА И ЦЕЛЕВЫЕ ПОКАЗАТЕЛИ ОЧИСТКИ
 *
 * Глубина очистки определяется не отраслью, а тем, куда уходит вода.
 * Один и тот же молокозавод при сбросе в городскую канализацию и в
 * канал получает разные схемы.
 *
 * Источники:
 *  - Постановление КМ РУз от 03.02.2010 № 11, приложение 1
 *    «Правила приёма производственных сточных вод … в коммунальные
 *    канализационные сети» — нормативы ПДК при сбросе в горсеть.
 *    Именно к этому документу отсылает п. 6.2 ҚМҚ 2.04.03-19 за
 *    допустимыми концентрациями при приёме на биологическую очистку;
 *    п. 6.59 — взвешенные перед биологией не более 150 мг/л, п. 6.2 —
 *    pH 6,5–8,5.
 *  - СанПиН РУз № 0318-15 «Гигиенические и противоэпидемические
 *    требования к охране воды водоёмов» — качество воды водного
 *    объекта; конкретные значения на выпуске определяются НДС в
 *    разрешении на специальное водопользование с учётом фонового
 *    качества и кратности разбавления.
 *
 * ВАЖНО: значения ниже — нормативная база предпроектной стадии.
 * Действующие требования конкретного объекта задают технические
 * условия водоканала или НДС; в анкете есть поле для их ввода,
 * и введённые значения имеют приоритет над таблицей.
 * ================================================================== */

import type { PollutantKey, StageKey } from "./industries";
import { L, type Text } from "./i18n";
import {
  BIO_INLET_LIMITS,
  KMK_2_04_03_19_DOC,
  PRIMARY_SETTLING,
  STAGE_EFFECTS,
} from "../../../../norms/kmk-2-04-03-19";

export type DischargeId = "sewer" | "water" | "relief" | "irrigation" | "reuse";

export type Discharge = {
  id: DischargeId;
  name: Text;
  hint: Text;
  /** целевые концентрации, мг/л; undefined — норматив задаётся ТУ/НДС */
  targets: Partial<Record<PollutantKey, number>>;
  ph: [number, number];
  /** ступени, обязательные для этой точки сброса */
  require: StageKey[];
  /** ступени, которые для этой точки сброса избыточны */
  drop: StageKey[];
  /** что писать в документе про происхождение цифр */
  source: Text;
  /** предупреждение проектировщику */
  note: Text;
};

export const DISCHARGES: Discharge[] = [
  {
    id: "sewer",
    name: L("Городская канализация", "Shahar kanalizatsiyasi", "Municipal sewer", "市政污水管网"),
    hint: L("Сброс в коммунальную сеть по договору с водоканалом", "Suv ta’minoti tashkiloti bilan shartnoma bo‘yicha kommunal tarmoqqa chiqarish", "Discharge to the municipal network under a utility contract", "按与自来水公司的合同排入市政管网"),
    /* ПКМ РУз № 11 от 03.02.2010, приложение 1; ВВ 150 мг/л совпадает с п. 6.59 ҚМҚ 2.04.03-19 */
    targets: { bod: 15, ss: PRIMARY_SETTLING.ssBeforeBioMaxMgL.value, fats: 1, petro: 1, tn: 1, tp: 2.5 },
    ph: [BIO_INLET_LIMITS.phMin, BIO_INLET_LIMITS.phMax],
    require: [],
    /* городские очистные доводят воду до норматива водоёма сами */
    drop: ["post", "disinfect"],
    source: `ПКМ РУз № 11 от 03.02.2010, приложение 1 (нормативы приёма в коммунальную канализацию) — этот же документ ${KMK_2_04_03_19_DOC.code} (п. 6.2) называет основанием допустимых концентраций при приёме на биологическую очистку; взвешенные перед биологической очисткой не более ${PRIMARY_SETTLING.ssBeforeBioMaxMgL.value} мг/л (${PRIMARY_SETTLING.ssBeforeBioMaxMgL.ref})`,
    note:
      "Азот нормируется как аммонийный, фосфор — как фосфаты. Значения приёма в РУз жёсткие: " +
      "по БПК и жирам они близки к нормативам водоёма, поэтому локальная очистка обязательна почти " +
      "для любого производства. Окончательные величины и перечень показателей задаёт водоканал в " +
      "технических условиях — при их наличии вводите значения из ТУ.",
  },
  {
    id: "water",
    name: L("Водный объект (река, канал, коллектор)", "Suv obyekti (daryo, kanal, kollektor)", "Surface water body (river, canal, drain)", "地表水体（河流、渠道、排水沟）"),
    hint: L("Выпуск в поверхностный водоём — нужен НДС и разрешение на спецводопользование", "Yer usti suv havzasiga chiqarish — chiqindi me’yori va maxsus suvdan foydalanish ruxsati kerak", "Outfall to a surface water body — a discharge permit is required", "排入地表水体——需取得排污许可"),
    /* значения на выпуске считаются по НДС; здесь — ориентир предпроектной стадии */
    targets: { bod: 3, ss: 15, fats: 0.5, petro: 0.05, tn: 10, tp: 1, cod: 30 },
    ph: [6.5, 8.5],
    require: ["post", "disinfect"],
    drop: [],
    source:
      "Ориентир предпроектной стадии по СанПиН РУз № 0318-15; фактические величины — по НДС в разрешении " +
      "на специальное водопользование, с учётом фона водоёма и кратности разбавления. " +
      `Достижимость: ${KMK_2_04_03_19_DOC.code} п. 6.10 — биологическая очистка до ${STAGE_EFFECTS.biological.bodFullOutMgL[0]}–${STAGE_EFFECTS.biological.bodFullOutMgL[1]} мг/л БПКполн и ${STAGE_EFFECTS.biological.ssOutMgL} мг/л ВВ, доочистка до ${STAGE_EFFECTS.tertiary.bodFullOutMgL[0]}–${STAGE_EFFECTS.tertiary.bodFullOutMgL[1]} мг/л БПКполн и ${STAGE_EFFECTS.tertiary.ssOutMgL[0]}–${STAGE_EFFECTS.tertiary.ssOutMgL[1]} мг/л ВВ`,
    note:
      "Это самый жёсткий сценарий: нужна глубокая биологическая очистка с нитри-денитрификацией, " +
      "доочистка фильтрацией и обеззараживание. Приведённые цифры — ориентировочные: расчёт НДС " +
      "выполняется проектировщиком по фоновому качеству водоёма и расходу, и может быть как мягче, " +
      "так и жёстче. Введите значения из НДС, если он уже получен.",
  },
  {
    id: "relief",
    name: L("Рельеф, поля фильтрации, накопитель", "Relef, filtratsiya maydonlari, to‘plagich", "Ground surface, filtration fields, storage pond", "地面、渗滤场、蓄水池"),
    hint: L("Сброс на местность или в испарительный накопитель", "Yerga yoki bug‘lanish to‘plagichiga chiqarish", "Discharge to the ground or to an evaporation pond", "排至地面或蒸发塘"),
    targets: { bod: 15, ss: 30, fats: 5, petro: 0.3, tn: 20, tp: 5 },
    ph: [6.5, 8.5],
    require: ["disinfect"],
    drop: [],
    source: "Условия согласовываются с органами санитарного и экологического надзора для конкретной площадки",
    note:
      "Единого норматива нет: требования зависят от глубины залегания грунтовых вод, состава грунтов и " +
      "расстояния до водозаборов. Обязательны обеззараживание и гидрогеологическое обоснование. " +
      "Значения приняты предварительно и подлежат согласованию.",
  },
  {
    id: "irrigation",
    name: L("Полив и орошение", "Sug‘orish", "Irrigation", "灌溉"),
    hint: L("Использование очищенной воды для полива насаждений или полей", "Tozalangan suvdan ko‘chatlar yoki dalalarni sug‘orishda foydalanish", "Use of treated water for irrigating plantings or fields", "处理后水用于绿化或农田灌溉"),
    targets: { bod: 15, ss: 30, fats: 5, petro: 0.3, tn: 30, tp: 10 },
    ph: [6.5, 8.5],
    require: ["disinfect"],
    drop: [],
    source: "Санитарные требования к использованию сточных вод для орошения; согласование с санитарной службой",
    note:
      "Азот и фосфор здесь полезны как удобрение — глубокое их удаление не требуется и удорожает станцию. " +
      "Главное — микробиология: обеззараживание обязательно, обычно с накопительной ёмкостью и контролем. " +
      "Для полива пищевых культур требования существенно строже, чем для технических насаждений и газонов.",
  },
  {
    id: "reuse",
    name: L("Оборотное водоснабжение", "Aylanma suv ta’minoti", "Water reuse / recirculation", "循环回用"),
    hint: L("Возврат воды в производство: мойка, охлаждение, техпроцесс", "Suvni ishlab chiqarishga qaytarish: yuvish, sovutish, texnologik jarayon", "Return of water to production: washing, cooling, process use", "回用于生产：冲洗、冷却、工艺用水"),
    targets: { bod: 5, ss: 5, fats: 0.5, petro: 0.05, tn: 15, tp: 2, cod: 30 },
    ph: [6.5, 8.5],
    require: ["post", "disinfect"],
    drop: [],
    source: "Технологические требования потребителя воды; нормируется не экологией, а процессом",
    note:
      "Нормирует не надзор, а сам техпроцесс: для мойки полов достаточно осветления и обеззараживания, " +
      "для оборотного водоснабжения котельной нужны жёсткость и солесодержание, для мойки тары — " +
      "питьевое качество. Обязательна продувка контура: соли накапливаются, часть воды всё равно " +
      "уходит на сброс. Укажите требования потребителя — без них расчёт доочистки условен.",
  },
];

export function findDischarge(id: string): Discharge | undefined {
  return DISCHARGES.find((d) => d.id === id);
}

/** цепочка с учётом точки сброса: лишнее убираем, недостающее добавляем */
export function chainForDischarge(chain: StageKey[], d: Discharge | undefined, industryId: string): StageKey[] {
  if (!d) return chain;

  /* обеззараживание не снимаем там, где оно обязательно по эпидемиологии */
  const keepDisinfect = ["hospital", "settlement", "hotel", "school", "restaurant", "poultry", "meat", "fish"].includes(industryId);

  let out = chain.filter((s) => !d.drop.includes(s) || (s === "disinfect" && keepDisinfect));

  for (const need of d.require) {
    if (!out.includes(need)) {
      /* доочистка — перед обеззараживанием, обеззараживание — перед осадком */
      const anchor = need === "post" ? out.indexOf("disinfect") : out.indexOf("sludge");
      if (anchor >= 0) out = [...out.slice(0, anchor), need, ...out.slice(anchor)];
      else out = [...out, need];
    }
  }
  return out;
}
